export const environment = {
  production: true,
  // serviceUrl: 'https://ukmqtt.meanhost.in/v1/api',
  // betaserviceUrl: 'https://ukmqtt.meanhost.in/v1/api'

  serviceUrl: 'https://video.bizilliant.com:5002',
  betaserviceUrl: 'https://video.bizilliant.com:5002'
};
